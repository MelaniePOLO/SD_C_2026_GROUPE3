/***************************************************************
 * UNIVERSITE : Université de Lomé (UL)
 * ETABLISSEMENT : Ecole Polytechnique de Lomé (EPL)
 * FILIERES : (GC / GM / IA-BD)
 * NIVEAU : Licence fondamentale 1
 *
 * UE : Structures de Données et Programmation C (SD+C)
 * EXERCICE : Gestion d'un parc d'ordinateurs (Exo 3)
 *
 * AUTEURS :
 *
 *   - POLO Tacbi Erésam  Mélanie (IA-BD)
 *   - KONOU Adjovi Sara(IA-BD)
 *   - ATANGUEGNIMA Dissirama Josephine(IA-BD)
 *   - DONKO    Kasséré     Ariel(IA-BD)
 *   - ADJEMINI  Anouwardine (IA-BD)
 *   - DJABIA Emmanuel Yepaab (GM)
 *   - KOUDO Kodzo Samuel     (GM)
 *   - LAKIGNAN Koboyo Carmine(GC)
 *   - SOGAN Akossiwa Winner Elbyre(GC)
 *
 * DATE : 23 Mars 2026
 *
 * DESCRIPTION :
 * Implémentation des fonctions de gestion d'un parc d'ordinateurs.
 * 
 * COMPILATEUR : VS Code / GCC
 ***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ordinateur.h"

// Utilitaire pour nettoyer le tampon d'entree standard
void nettoyerTampon() {
    int cacaratere;
    while ((cacaratere = getchar()) != '\n' && cacaratere != EOF);
}

// Utilitaire pour saisir une chaine proprement et l'allouer dynamiquement
char* saisirChaine(const char* message) {
    char tampon[256];
    printf("%s", message);
    if (fgets(tampon, sizeof(tampon), stdin) != NULL) {
        size_t longueur = strlen(tampon);
        if (longueur > 0 && tampon[longueur-1] == '\n') {
            tampon[longueur-1] = '\0';
        } else {
            nettoyerTampon();
        }
        char *chaine = malloc(strlen(tampon) + 1);
        if (chaine != NULL) {
            strcpy(chaine, tampon);
        }
        return chaine;
    }
    return NULL;
}

void initialiserParc(ParcOrdinateurs *parc) {
    parc->taille = 0;
    for(int i = 0; i < MAX_ORDI; i++) {
        parc->liste[i] = NULL;
    }
}

int ajouterOrdinateur(ParcOrdinateurs *parc) {
    if (parc->taille >= MAX_ORDI) {
        printf("Erreur : Le parc est plein (limite de %d ordinateurs atteinte).\n", MAX_ORDI);
        return 0;
    }

    Ordinateur *nouvelOrdi = (Ordinateur*)malloc(sizeof(Ordinateur));
    if (nouvelOrdi == NULL) {
        printf("Erreur d'allocation memoire.\n");
        return 0;
    }

    printf("\n--- Ajout d'un nouvel ordinateur ---\n");
    printf("Numero de carte du detenteur : ");
    while (scanf("%d", &nouvelOrdi->numero_carte) != 1) {
        printf("Saisie invalide. Reessayez : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    nouvelOrdi->specialite = saisirChaine("Specialite du detenteur : ");
    nouvelOrdi->numero_serie = saisirChaine("Numero de serie : ");
    nouvelOrdi->marque = saisirChaine("Marque : ");

    printf("Vitesse du processeur (en Ghz) : ");
    while (scanf("%f", &nouvelOrdi->vitesse_cpu) != 1) {
        printf("Saisie invalide. Reessayez : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    printf("Memoire RAM (en Go) : ");
    while (scanf("%d", &nouvelOrdi->ram) != 1) {
        printf("Saisie invalide. Reessayez : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    printf("Taille du disque dur (en Go) : ");
    while (scanf("%d", &nouvelOrdi->taille_disque) != 1) {
        printf("Saisie invalide. Reessayez : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    printf("Prix estime de l'ordinateur (en F cfa) : ");
    while (scanf("%d", &nouvelOrdi->prix_estime) != 1) {
        printf("Saisie invalide. Reessayez : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    parc->liste[parc->taille] = nouvelOrdi;
    parc->taille++;

    printf("Ordinateur ajoute avec succes !\n");
    return 1;
}

void listerOrdinateurs(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide.\n");
        return;
    }

    printf("\nListe des ordinateurs :\n");
    printf("%-6s | %-12s | %-12s | %-15s | %-12s | %-8s | %-5s | %-8s | %-10s\n", 
           "Indice", "Num. Carte", "Specialite", "Num. Serie", "Marque", "CPU(GHz)", "RAM", "Disque", "Prix(Fcfa)");
    printf("--------------------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < parc->taille; i++) {
        Ordinateur *o = parc->liste[i];
        printf("%-6d | %-12d | %-12.12s | %-15.15s | %-12.12s | %-8.2f | %-5d | %-8d | %-10d\n", 
               i + 1, o->numero_carte, 
               o->specialite ? o->specialite : "N/A", 
               o->numero_serie ? o->numero_serie : "N/A", 
               o->marque ? o->marque : "N/A", 
               o->vitesse_cpu, o->ram, o->taille_disque, o->prix_estime);
    }
}

void afficherDetailsOrdinateur(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide.\n");
        return;
    }

    int indice;
    printf("\nEntrez le numero (Indice) de l'ordinateur a afficher : ");
    if (scanf("%d", &indice) != 1) {
        nettoyerTampon();
        printf("Entree invalide.\n");
        return;
    }
    nettoyerTampon();

    if (indice < 1 || indice > parc->taille) {
        printf("Indice invalide. Le parc contient %d ordinateurs.\n", parc->taille);
        return;
    }

    Ordinateur *o = parc->liste[indice - 1];
    printf("\n--- Details de l'ordinateur %d ---\n", indice);
    printf("Numero de carte du detenteur : %d\n", o->numero_carte);
    printf("Specialite du detenteur      : %s\n", o->specialite ? o->specialite : "Non renseigne");
    printf("Numero de serie              : %s\n", o->numero_serie ? o->numero_serie : "Non renseigne");
    printf("Marque                       : %s\n", o->marque ? o->marque : "Non renseigne");
    printf("Vitesse du processeur        : %.2f GHz\n", o->vitesse_cpu);
    printf("Memoire RAM                  : %d Go\n", o->ram);
    printf("Taille du disque dur         : %d Go\n", o->taille_disque);
    printf("Prix estime                  : %d F cfa\n", o->prix_estime);
    printf("---------------------------------\n");
}

int supprimerOrdinateur(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide, rien a supprimer.\n");
        return 0;
    }

    int indice;
    printf("\nEntrez le numero (Indice) de l'ordinateur a supprimer : ");
    if (scanf("%d", &indice) != 1) {
        nettoyerTampon();
        printf("Entree invalide.\n");
        return 0;
    }
    nettoyerTampon();

    if (indice < 1 || indice > parc->taille) {
        printf("Indice invalide. Le parc contient %d ordinateurs.\n", parc->taille);
        return 0;
    }

    int vrai_indice = indice - 1;
    Ordinateur *o = parc->liste[vrai_indice];

    // Liberer les chaines allouees dynamiquement
    if (o->specialite) free(o->specialite);
    if (o->numero_serie) free(o->numero_serie);
    if (o->marque) free(o->marque);

    // Liberer la structure ordinateur
    free(o);

    // Decaler les elements pour boucher le trou dans le tableau
    for (int i = vrai_indice; i < parc->taille - 1; i++) {
        parc->liste[i] = parc->liste[i + 1];
    }
    
    parc->liste[parc->taille - 1] = NULL;
    parc->taille--;

    printf("Ordinateur supprime avec succes !\n");
    return 1;
}

void repartirParSpecialite(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide.\n");
        return;
    }
    
    char* specChoisie = saisirChaine("\nEntrez la specialite pour filtrer : ");
    if (!specChoisie) return;

    printf("\n--- Ordinateurs pour la specialite : %s ---\n", specChoisie);
    int nombre_trouves = 0;
    
    for (int i = 0; i < parc->taille; i++) {
        Ordinateur *o = parc->liste[i];
        if (o->specialite && strcmp(o->specialite, specChoisie) == 0) {
            printf("- [Indice %d] %s, %s (Carte DET: %d),prix: %d\n", i+1, o->marque, o->numero_serie, o->numero_carte, o->prix_estime);
            nombre_trouves++;
        }
    }
    
    if (nombre_trouves == 0) {
        printf("Aucun ordinateur trouve pour cette specialite.\n");
    }
    
    free(specChoisie);
}

void repartirParMarque(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide.\n");
        return;
    }
    
    char* marqueChoisie = saisirChaine("\nEntrez la marque pour filtrer : ");
    if (!marqueChoisie) return;

    printf("\n--- Ordinateurs de la marque : %s ---\n", marqueChoisie);
    int nombre_trouves = 0;
    
    for (int i = 0; i < parc->taille; i++) {
        Ordinateur *o = parc->liste[i];
        if (o->marque && strcmp(o->marque, marqueChoisie) == 0) {
             printf("- [Indice %d] Specialite: %s, Num Serie: %s (Carte DET: %d) prix:%d\n", i+1, o->specialite, o->numero_serie, o->numero_carte, o->prix_estime);
            nombre_trouves++;
        }
    }
    
    if (nombre_trouves == 0) {
        printf("Aucun ordinateur trouve pour cette marque.\n");
    }
    
    free(marqueChoisie);
}

void filtrerParPrix(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide.\n");
        return;
    }

    int prix_min, prix_max;

    printf("\n--- Filtrage par prix estime ---\n");
    printf("Entrez le prix minimum (en F cfa) : ");
    while (scanf("%d", &prix_min) != 1 || prix_min < 0) {
        printf("Saisie invalide. Entrez un prix positif : ");
        nettoyerTampon();
    }
    nettoyerTampon();

    printf("Entrez le prix maximum (en F cfa) : ");
    while (scanf("%d", &prix_max) != 1 || prix_max < prix_min) {
        printf("Saisie invalide. Le prix max doit etre >= %d : ", prix_min);
        nettoyerTampon();
    }
    nettoyerTampon();

    printf("\n--- Ordinateurs avec un prix entre %d et %d F cfa ---\n", prix_min, prix_max);
    printf("%-6s | %-12s | %-12s | %-15s | %-12s | %-8s | %-5s | %-8s | %-10s\n",
           "Indice", "Num. Carte", "Specialite", "Num. Serie", "Marque", "CPU(GHz)", "RAM", "Disque", "Prix(Fcfa)");
    printf("--------------------------------------------------------------------------------------------------------------\n");

    int nombre_trouves = 0;
    for (int i = 0; i < parc->taille; i++) {
        Ordinateur *o = parc->liste[i];
        if (o->prix_estime >= prix_min && o->prix_estime <= prix_max) {
            printf("%-6d | %-12d | %-12.12s | %-15.15s | %-12.12s | %-8.2f | %-5d | %-8d | %-10d\n",
                   i + 1, o->numero_carte,
                   o->specialite ? o->specialite : "N/A",
                   o->numero_serie ? o->numero_serie : "N/A",
                   o->marque ? o->marque : "N/A",
                   o->vitesse_cpu, o->ram, o->taille_disque, o->prix_estime);
            nombre_trouves++;
        }
    }

    if (nombre_trouves == 0) {
        printf("Aucun ordinateur trouve dans cette fourchette de prix.\n");
    } else {
        printf("--------------------------------------------------------------------------------------------------------------\n");
        printf("%d ordinateur(s) trouve(s) dans cette fourchette de prix.\n", nombre_trouves);
    }
}

// Fonction de comparaison pour la fonction de tri (ordre decroissant de vitesse)
int comparerVitesse(const void *a, const void *b) {
    Ordinateur *ordiA = *(Ordinateur**)a;
    Ordinateur *ordiB = *(Ordinateur**)b;
    
    if (ordiA->vitesse_cpu < ordiB->vitesse_cpu) return 1;
    if (ordiA->vitesse_cpu > ordiB->vitesse_cpu) return -1;
    return 0;
}

void classerParVitesse(ParcOrdinateurs *parc) {
    if (parc->taille <= 1) {
        printf("\nPas assez d'ordinateurs pour trier.\n");
        return;
    }

    qsort(parc->liste, parc->taille, sizeof(Ordinateur*), comparerVitesse);
    printf("\nLe parc a ete trie par vitesse (de la plus grande a la plus petite).\n");
    listerOrdinateurs(parc);
}

void calculerValeurTotale(ParcOrdinateurs *parc) {
    if (parc->taille == 0) {
        printf("\nLe parc est vide, valeur totale : 0 F cfa\n");
        return;
    }

    long long somme_totale = 0;
    for (int i = 0; i < parc->taille; i++) {
        somme_totale += parc->liste[i]->prix_estime;
    }

    printf("\nLa valeur totale des %d ordinateurs du parc est de : %lld F cfa\n", parc->taille, somme_totale);
}

void libererParc(ParcOrdinateurs *parc) {
    for (int i = 0; i < parc->taille; i++) {
        Ordinateur *o = parc->liste[i];
        if (o) {
            if (o->specialite) free(o->specialite);
            if (o->numero_serie) free(o->numero_serie);
            if (o->marque) free(o->marque);
            free(o); // Libere la memoire de la structure elle-meme
        }
        parc->liste[i] = NULL;
    }
    parc->taille = 0;
    printf("Memoire du parc liberee proprement.\n");
}
