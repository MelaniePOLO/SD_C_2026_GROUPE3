/***************************************************************
 * UNIVERSITE : Université de Lomé (UL)
 * ETABLISSEMENT : Ecole Polytechnique de Lomé (EPL)
 * FILIERES : (GC / GM / IA-BD)
 * NIVEAU : Licence fondamentale 1
 *
 * UE : Structures de Données et Programmation C (SD+C)
 * EXERCICE : Gestion d'un parc d'ordinateurs (Exo 3)
 *
 * AUTEURS :
 *
 *   - POLO Tacbi Erésam  Mélanie (IA-BD)
 *   - KONOU Adjovi Sara(IA-BD)
 *   - ATANGUEGNIMA Dissirama Josephine(IA-BD)
 *   - DONKO    Kasséré     Ariel(IA-BD)
 *   - ADJEMINI  Anouwardine (IA-BD)
 *   - DJABIA Emmanuel Yepaab (GM)
 *   - KOUDO Kodzo Samuel     (GM)
 *   - LAKIGNAN Koboyo Carmine(GC)
 *   - SOGAN Akossiwa Winner Elbyre(GC)
 *
 * DATE : 23 Mars 2026
 *
 * DESCRIPTION :
 * Définition des structures et prototypes de gestion d'un parc d'ordinateurs.
 * 
 * COMPILATEUR : VS Code / GCC
 ***************************************************************/
#ifndef ORDINATEUR_H
#define ORDINATEUR_H

#define MAX_ORDI 300

typedef struct {
    int numero_carte;
    char *specialite;
    char *numero_serie;
    char *marque;
    float vitesse_cpu; // en GHz
    int ram; // en Go
    int taille_disque; // en Go
    int prix_estime; // en F cfa
} Ordinateur;

// Structure globale pour le parc (Tableau de pointeurs) et sa taille
typedef struct {
    Ordinateur *liste[MAX_ORDI];
    int taille;
} ParcOrdinateurs;

// Prototypes des fonctions principales
void initialiserParc(ParcOrdinateurs *parc);
int ajouterOrdinateur(ParcOrdinateurs *parc);
void listerOrdinateurs(ParcOrdinateurs *parc);
void afficherDetailsOrdinateur(ParcOrdinateurs *parc);
int supprimerOrdinateur(ParcOrdinateurs *parc);
void repartirParSpecialite(ParcOrdinateurs *parc);
void repartirParMarque(ParcOrdinateurs *parc);
void filtrerParPrix(ParcOrdinateurs *parc);
void classerParVitesse(ParcOrdinateurs *parc);
void calculerValeurTotale(ParcOrdinateurs *parc);
void libererParc(ParcOrdinateurs *parc);

// Fonctions utilitaires
char* saisirChaine(const char* message);

#endif
