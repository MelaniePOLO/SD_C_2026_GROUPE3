# Gestion d'un Parc d'Ordinateurs (Exercice 3)

Ce projet a été réalisé en langage C dans le cadre du module "Structures de Données et Programmation C (SD+C)" en Licence fondamentale 1 à l'Université de Lomé (EPL).

## 📝 Description
Il s'agit d'un programme permettant de gérer un parc de matériels informatiques (ordinateurs). Il offre les fonctionnalités suivantes via un menu interactif :
- Ajouter un nouvel ordinateur (avec diverses caractéristiques : marque, numéro de série, CPU, RAM, etc.)
- Lister l'intégralité des ordinateurs du parc
- Afficher les détails complets d'un ordinateur sélectionné par son indice
- Supprimer un ordinateur du parc
- Filtrer la liste des ordinateurs par **Spécialité** ou par **Marque**
- Trier automatiquement les ordinateurs par vitesse de processeur (CPU) décroissante
- Calculer la valeur financière totale estimée de tout le parc

## 📁 Structure du dossier
* `main.c` : Programme principal. Contient la boucle principale et le menu utilisateur.
* `Exo3_Gestion_Ordinateurs/ordinateur.h` : Structures de données (Ordinateur, ParcOrdinateurs) et déclarations des différentes fonctions.
* `Exo3_Gestion_Ordinateurs/ordinateur.c` : Codage et implémentation concrète des opérations applicables au parc.

## 🚀 Compilation et Exécution

Ce projet a été conçu pour être compilé facilement avec **GCC**, notamment sous **VS Code**. 

1. Ouvrez un terminal à la racine du projet.
2. Tapez la commande suivante pour **compiler** :
   ```bash
   gcc Exo3_Gestion_Ordinateurs\ordinateur.c main.c -o gestionaire.exe
   ```
3. Pour **exécuter** le programme une fois compilé :
   ```bash
   .\gestionaire.exe
   ```

## 👥 Auteurs

**Filière IA-BD**
* POLO Tacbi Erésam Mélanie
* KONOU Adjovi Sara
* ATANGUEGNIMA Dissirama Josephine
* DONKO Kasséré Ariel
* ADJEMINI Anouwardine

**Filière GM**
* DJABIA Emmanuel Yepaab
* KOUDO Kodzo Samuel

**Filière GC**
* LAKIGNAN Koboyo Carmine
* SOGAN Akossiwa Winner Elbyre
