/***************************************************************
 * UNIVERSITE : Université de Lomé (UL)
 * ETABLISSEMENT : Ecole Polytechnique de Lomé (EPL)
 * FILIERES : (GC / GM / IA-BD)
 * NIVEAU : Licence fondamentale 1
 *
 * UE : Structures de Données et Programmation C (SD+C)
 * EXERCICE : Gestion d'un parc d'ordinateurs (Exo 3)
 *
 * AUTEURS :
 *
 *   - POLO Tacbi Erésam  Mélanie (IA-BD)
 *   - KONOU Adjovi Sara(IA-BD)
 *   - ATANGUEGNIMA Dissirama Josephine(IA-BD)
 *   - DONKO    Kasséré     Ariel(IA-BD)
 *   - ADJEMINI  Anouwardine (IA-BD)
 *   - DJABIA Emmanuel Yepaab (GM)
 *   - KOUDO Kodzo Samuel     (GM)
 *   - LAKIGNAN Koboyo Carmine(GC)
 *   - SOGAN Akossiwa Winner Elbyre(GC)
 *
 * DATE : 23 Mars 2026
 *
 * DESCRIPTION :
 * Programme de gestion d'un parc de matériels informatiques (ordinateurs).
 * Il permet l'ajout, la suppression, la liste, le filtrage par spécialité
 * ou marque, le tri par vitesse, et le calcul de la valeur totale du parc.
 * 
 * COMPILATEUR : VS Code / GCC
 ***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "ordinateur.h"

void afficherMenu() {
    printf("\n==== GESTION DU PARC D'ORDINATEURS ====\n");
    printf("1. Ajouter un ordinateur\n");
    printf("2. Lister tous les ordinateurs\n");
    printf("3. Afficher les details d'un ordinateur\n");
    printf("4. Supprimer un ordinateur\n");
    printf("5. Filtrer par specialite\n");
    printf("6. Filtrer par marque\n");
    printf("7. Filtrer par prix estime\n");
    printf("8. Trier les ordinateurs par vitesse de CPU\n");
    printf("9. Calculer la valeur totale du parc\n");
    printf("10. Quitter\n");
    printf("=======================================\n");
    printf("Votre choix : ");
}

int main() {
    ParcOrdinateurs parc;
    initialiserParc(&parc);
    int choix;

    do {
        afficherMenu();
        if (scanf("%d", &choix) != 1) {
            printf("Veuillez entrer un nombre valide.\n");
            int buffer;
            while ((buffer = getchar()) != '\n' && buffer != EOF);
            continue;
        }

        // Nettoyer le buffer d'entree apres le scanf du menu
        int buffer;
        while ((buffer = getchar()) != '\n' && buffer != EOF);

        switch (choix) {
            case 1:
                ajouterOrdinateur(&parc);
                break;
            case 2:
                listerOrdinateurs(&parc);
                break;
            case 3:
                afficherDetailsOrdinateur(&parc);
                break;
            case 4:
                supprimerOrdinateur(&parc);
                break;
            case 5:
                repartirParSpecialite(&parc);
                break;
            case 6:
                repartirParMarque(&parc);
                break;
            case 7:
                filtrerParPrix(&parc);
                break;
            case 8:
                classerParVitesse(&parc);
                break;
            case 9:
                calculerValeurTotale(&parc);
                break;
            case 10:
                printf("Fermeture de l'application...\n");
                break;
            default:
                printf("Choix invalide. Veuillez reessayer.\n");
                break;
        }
    } while (choix != 10);

    libererParc(&parc);
    return 0;
}
